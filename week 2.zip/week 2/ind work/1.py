a = input("enter your array:\n")

arr = a.split()

result = list(reversed(arr))
print("reversed array:", result)
