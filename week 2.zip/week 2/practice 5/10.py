s = input('enter your text:\n')
print(s.title())