n = 0
s = input('enter your text:\n')
for i in range(len(s)):
    if s[i] == 't':
        n += 1
print(n)
