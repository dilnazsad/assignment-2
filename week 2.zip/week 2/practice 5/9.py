text = input('enter your text:\n')
word = input('enter your word:\n')
print(text.count(word))