text = input("enter the text:")

x = text.replace(':', '%')

print(x)
print(len(x))

