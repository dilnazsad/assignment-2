s = input("enter the text with Caps Lock:\n")
print(s.lower())